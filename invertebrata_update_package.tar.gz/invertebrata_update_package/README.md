# INVERTEBRATA QA – Drop-in Content Update Package
Version: 3.0  
Date: 2026-11-07  
Terminology: Tamil Nadu State Board 11th Zoology

## Contents
- `invertebrata_content_final.json` — Complete bilingual content (notes, classes, 60 quiz questions, privacy policy)

## How to Integrate

### Option A: JSON-based content (Recommended)
1. Copy `invertebrata_content_final.json` into your app’s `assets/` folder.
2. Load it at runtime using your existing data layer or a simple JSON parser.
3. Map the `phyla` and `quiz_questions` arrays to your UI.

### Option B: Android string resources
If your app uses `strings.xml`:
1. Extract key strings from the JSON.
2. Place English strings in `res/values/strings.xml`.
3. Place Tamil strings in `res/values-ta/strings.xml`.

## Privacy Policy
The JSON includes a ready bilingual privacy policy under the `privacy_policy` key. Display it on an About / Privacy screen.

## Coverage
- 10 phyla (including Ctenophora and Hemichordata)
- Class-level notes for major groups
- 60 bilingual quiz questions with explanations
- Exam tips and comparison data
- Fully offline design

## Notes
- All Tamil terms follow Tamil Nadu State Board textbooks.
- Content is structured for easy mobile reading.
- No personal data is collected by design.

## Integration Checklist
- [ ] Copy JSON to assets
- [ ] Update data loading code if needed
- [ ] Add Privacy screen using the included policy
- [ ] Test bilingual display
- [ ] Verify quiz scoring and explanations
- [ ] Rebuild and sign APK

For questions or further customization, refer to the JSON structure.  
All fields are self-documenting (`name_en` / `name_ta`, `notes`, `key_features`, `quiz_questions`, etc.).
