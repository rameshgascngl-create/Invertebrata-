#!/usr/bin/env python3
"""Apply only the book-chapter reference; image registry wiring requires inspection."""
from pathlib import Path
p=Path('native-app/app/src/main/java/com/gasczoology/invertebratelab/data/ParameciumBookChapter.kt')
s=p.read_text()
needle='                    btable("Stages of conjugation", "இணைவின் நிலைகள்",'
insert='''                    bfig("paramecium/reproduction-approved", "Paramecium caudatum: accepted overview of transverse binary fission and conjugation. Refer to the detailed text for nuclear reorganisation." to "பாரமீசியம் காடேட்டம்: குறுக்கான இருசமப்பிளவு மற்றும் இணைவு பற்றிய ஏற்றுக்கொள்ளப்பட்ட தொகுப்புப் படம். உட்கரு மறுசீரமைப்பின் விரிவான விளக்கத்தைப் பாடப்பகுதியில் காண்க."),
'''
if 'paramecium/reproduction-approved' in s:
    print('Chapter figure already present; no change')
elif s.count(needle)!=1:
    raise SystemExit('Expected conjugation table anchor not found exactly once')
else:
    p.write_text(s.replace(needle,insert+needle))
    print('Inserted book figure reference; image registry wiring remains required')
