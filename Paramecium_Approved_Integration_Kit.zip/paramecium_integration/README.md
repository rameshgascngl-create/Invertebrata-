# Accepted Paramecium reproduction PNG — integration package

Source branch: `audit/undergraduate-coverage-register-20261114`.
Last confirmed HEAD before package creation: `24e6f6db7e0408f564e0191a5ec30d0e88b42ab5`.

The PNG is user accepted. **No additional illustration generation or review is required for this integration.**

File: `assets/paramecium-reproduction-approved.png` (1536 × 1024 RGB PNG)
SHA-256: `8f54a66d89843688d64108cc6ebacae35db497e2bbb8bcbef4c959eefbb44d51`

## Apply
1. Check out the current audit branch and review changes since the checkpoint above.
2. Inspect the existing `bfig`/figure asset registry and copy the PNG to its appropriate asset directory. Register the figure key `paramecium/reproduction-approved` using the same mechanism as existing `paramecium/external-cilia` figures. Do not blindly assume `assets/` is the application's runtime directory.
3. Run `python3 integrate.py` at the repository root to insert the figure reference immediately before the conjugation-stage table. Review the diff before committing.
4. Verify full-screen zoom, Tamil 200% and English 100% screenshots, image credits, and offline rendering. Compile and run instrumentation before making a QA APK.

**This is a portable integration kit, not an integrated or tested APK.** It intentionally does not invent the existing figure registry's file location.
