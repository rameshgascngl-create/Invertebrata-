Pila globosa: three separate undergraduate teaching schematics.
Files: pila_excretory_system.png, pila_male_reproductive_system.png, pila_female_reproductive_system.png.
The ovary caption was corrected to '(branched gonad)'. These are educational schematics, not dissection-grade reference plates.
English terminology is embedded. Suggested Tamil lesson captions: கழிவுநீக்க மண்டலம்; ஆண் இனப்பெருக்க மண்டலம்; பெண் இனப்பெருக்க மண்டலம்.
Review before release: ensure labels readable on phone and that figure is presented as a schematic.
