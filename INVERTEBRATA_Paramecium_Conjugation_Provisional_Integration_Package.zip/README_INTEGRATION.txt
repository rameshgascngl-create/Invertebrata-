INVERTEBRATA PARAMECIUM — PROVISIONAL ARTWORK INTAKE

This ZIP contains the user-approved 8-panel conjugation PNG, its checksum and review record.
No Android source code is modified by this ZIP.

Integration steps for repository maintainer:
1. Place PNG in the project’s existing PNG asset location after checking the actual asset registry and naming conventions.
2. Add an OPTIONAL, explicitly provisional conjugation reference to the existing simulator/viewer. Do not replace accepted figures or invent a drawable name.
3. Preserve original PNG and provenance manifest; do not compress or crop without updating checksum.
4. Run exact-commit JVM/build and API34 Tamil 100%/200% emulator tests. Inspect full-screen 200% zoom screenshots.
5. Keep independent Zoology, Tamil, rights, physical-device and production signing gates open.

Scientific QA: conjugation is genetic exchange, not binary fission; stage 5 arrow endpoints and stage 8 nuclear reorganisation require independent review.
