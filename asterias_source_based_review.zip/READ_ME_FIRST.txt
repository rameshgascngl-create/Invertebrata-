ASTERIAS SOURCE-BASED REVIEW ASSETS — NOT FOR STUDENT RELEASE

Digestive plate: preserves the user's supplied anatomical scan and its original leader lines. It includes other systems and must not be misrepresented as an isolated digestive-only illustration. Original labeling and accuracy still require checking.
Water-vascular plate: preserves the user's central-disc reference; NOT a complete five-arm standalone system diagram.
Body-wall plate: separate transverse-section reference, not a replacement for an entire organ-system plate.

These files are intentionally named reference_ONLY; do not replace type_studies/asterias/ mandatory images with them. Source publication rights and academic editorial approval remain pending. No repository integration or Android QA has been performed.
