# Pila Android staging package

Contains four original-reference crops staged exclusively under `review_only/pila/`, **not** `type_studies/pila/`. No mandatory slot is filled, and no academic gate is bypassed.

To stage locally, copy `app/src/main/assets/review_only/pila/` into `native-app/app/src/main/assets/review_only/pila/` in the Android project. The current student-facing gallery does not load these images.

Before promoting an image to `type_studies/pila/external.png`, verify source license, anatomical accuracy, label endpoints, Tamil terminology, duplicate-image hashes, and Android screenshot/device QA. The four separate reference crops must not be used to fill unrelated mandatory plate slots.
